const masterKey = "$2a$10$zl7SIybkoXA7ndkK3MMq6eBspFGQm/h0KG6AMDiujFfzG2ZpaV.D.";


const deck = [

  { name: "The Mirror Gate", meaning: "Reflects your inner duality and hidden truths." },

  { name: "Skeleton Spiral", meaning: "A descent into the bones of your becoming." },

  { name: "Chrono Cross", meaning: "Time folds and unfolds—choose your moment." },

  // ✶ Add your full Codex deck cards here

];

const positions = ["Past Influence", "Present Energy", "Emerging Future"];

function drawSpread() {

  const output = document.getElementById('engine-output');

  const drawn = [];

  while (drawn.length < 3) {

    const card = deck[Math.floor(Math.random() * deck.length)];

    if (!drawn.includes(card)) drawn.push(card);

  }

  output.innerHTML = drawn.map((card, i) => `

    <div class="card-draw">

      <h3>${positions[i]}: ${card.name}</h3>

      <p>${card.meaning}</p>

    </div>

  `).join('');

}

const intentions = ["Release", "Manifest", "Protect", "Transform"];

const actions = {

  Release: [

    "Light a black candle and breathe out what no longer serves.",

    "Write a word on paper and burn it with intention.",

    "Stand barefoot and whisper your letting go into the earth."

  ],

  Manifest: [

    "Draw a sigil of your desire and place it under moonlight.",

    "Speak your intention aloud three times with open palms.",

    "Anoint your third eye with oil and visualize the outcome."

  ],

  Protect: [

    "Circle yourself with salt or symbolic glyphs.",

    "Chant your name followed by 'I am shielded'.",

    "Place a stone or token at each cardinal direction."

  ],

  Transform: [

    "Breathe in deeply and exhale with a sound.",

    "Write your current self and future self on opposite pages.",

    "Burn herbs while visualizing your metamorphosis."

  ]

};

function createRitual() {

  const output = document.getElementById('engine-output');

  const intent = intentions[Math.floor(Math.random() * intentions.length)];

  const steps = actions[intent];

  output.innerHTML = `

    <h3>🕯️ Ritual of ${intent}</h3>

    <ol>${steps.map(step => `<li>${step}</li>`).join('')}</ol>

  `;

}

function revealGlyph(symbol, meaning) {

  const output = document.getElementById('engine-output');

  output.innerHTML = `<h3>${symbol}</h3><p>${meaning}</p>`;

}

function setEngineMode(mode) {

  const output = document.getElementById('engine-output');

  if (mode === 'draw') {

    drawSpread();

  } else if (mode === 'prompt') {

    createRitual();

  } else if (mode === 'glyph') {

    output.innerHTML = `

      <p>Select a glyph to reveal its meaning:</p>

      <div class="glyph-grid">

        <button onclick="revealGlyph('🜁', 'Air: Breath, clarity, new beginnings')">🜁</button>

        <button onclick="revealGlyph('🜂', 'Fire: Will, transformation, passion')">🜂</button>

        <button onclick="revealGlyph('🜄', 'Water: Emotion, intuition, flow')">🜄</button>

      </div>

    `;

  }// Save notes to localStorage on input

const notepad = document.getElementById("notepad");

if (notepad) {

  notepad.value = localStorage.getItem("keeismNotes") || "";

  notepad.addEventListener("input", () => {

    localStorage.setItem("keeismNotes", notepad.value);

  });

}// Example: Toggle ritual section visibility

const ritualToggle = document.getElementById("toggle-ritual");

const ritualSection = document.getElementById("ritual-section");

if (ritualToggle && ritualSection) {

  ritualToggle.addEventListener("click", () => {

    ritualSection.classList.toggle("active");

  });

}const notepad = document.getElementById("notepad");

if (notepad) {

  notepad.value = localStorage.getItem("keeismNotes") || "";

  notepad.addEventListener("input", () => {

    localStorage.setItem("keeismNotes", notepad.value);

  });

}function revealCard(element, title, message) {

  element.innerHTML = `

    <div class="card-face">

      <strong>${title}</strong><br/>

      <em>${message}</em>

    </div>

  `;

  element.style.background = "linear-gradient(135deg, #fb9ed9, #ffbae3)";

  element.style.color = "#2b001b";

  element.style.boxShadow = "0 0 20px #ffc9e9";

}


  
  
  
  
  
 